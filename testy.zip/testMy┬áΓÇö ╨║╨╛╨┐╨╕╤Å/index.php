<?php
    $title = "Главная";
    require_once "blocks/header.php";

?>
    <h1 class="center">Kali linux</h1>
<div><a href="https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://www.kali.org/&ved=2ahUKEwio5aDhu--GAxXJJRAIHZzgBXQQFnoECAgQAQ&usg=AOvVaw3j7AL-f4E1FDyRP_ygi8cR">Официальный сайт</a></div>
<?php
    require_once "blocks/footer.php";

?>