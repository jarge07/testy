<footer>
    Автор vlad &copy; 2024
</footer>
</body>
</html>